
% θ(t): impact of school calendar on transmIysion rates among children on day t; set to one on school days, reduced on weekends, holItays and school closures
theta = 0.451;
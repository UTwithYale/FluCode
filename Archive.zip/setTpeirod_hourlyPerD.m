Tpeirod = 7*14;%7*14;
hourlyPerD = 5; % 5 parts each day